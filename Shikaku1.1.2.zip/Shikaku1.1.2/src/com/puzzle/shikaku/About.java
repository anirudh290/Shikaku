package com.puzzle.shikaku;




import android.app.Activity;
import android.os.Bundle;

//Referenced from Hello, Android, E. Burnette, The Pragmatic Programmers (2009).

public class About extends Activity { 
	 @Override
	    public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.about);//Creating a new activity for "about".
	    }
}
