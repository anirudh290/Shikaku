package com.puzzle.shikaku.Util;

//Referenced from http://www.goldb.org/stopwatchjava.html

public class ScoreTimer {
    
    private long timerBegin = 0;
    private long timerEnd = 0;
    private boolean timerTicking = false;

    
    public void begintimer() {
        this.timerBegin = System.currentTimeMillis();
        this.timerTicking = true;
    }

    
    public void endtimer() {
        this.timerEnd = System.currentTimeMillis();
        this.timerTicking = false;
    }

    
 
    public long retrieveExpiredTime() {
        long expiredTime;
        if (timerTicking) {
             expiredTime = (System.currentTimeMillis() - timerBegin);
        }
        else {
            expiredTime = (timerEnd - timerBegin);
        }
        return expiredTime;
    }
    
    
    
    public long retrieveExpiredTimeSeconds() {
        long expiredTime;
        if (timerTicking) {
            expiredTime = ((System.currentTimeMillis() - timerBegin) / 1000);
        }
        else {
            expiredTime = ((timerEnd - timerBegin) / 1000);
        }
        return expiredTime;
    }
 
    public static void main(String[] args) {
        ScoreTimer t = new ScoreTimer();
        t.begintimer();
        t.endtimer();
        System.out.println("milliseconds: " + t.retrieveExpiredTime());
    }
}