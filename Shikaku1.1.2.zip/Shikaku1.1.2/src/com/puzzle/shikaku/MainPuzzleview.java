package com.puzzle.shikaku;

import java.util.LinkedList;
import java.util.Queue;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.puzzle.shikaku.Util.ScoreTimer;
import com.puzzle.shikaku.view.CustomSpinner;
import com.puzzle.shikaku.view.Shikakuview;


public class MainPuzzleview extends Activity implements OnItemSelectedListener,OnClickListener{
	
	// Referenced from Hello, Android, E. Burnette, The Pragmatic Programmers (2009).
	
	private Shikakuview shikakuview;
	public static final String KEY_SELECTION = 
			"org.shikaku.Puzzle";
	public static final int NPUZ_1 = 0;
	public static final int MPUZ_1 = 1;
	public static final int EPUZ_1 = 2;
	public static final int NPUZ_2 = 3;
	public static final int MPUZ_2 = 4;
	public static final int EPUZ_2 = 5;
	public static final int NPUZ_3 = 6;
	public static final int MPUZ_3 = 7;
	public static final int EPUZ_3 = 8;


	final int BEGIN_TIMER = 0;
	final int END_TIMER = 1;
	final int REFRESH_TIMER = 2;

	TextView txtTimer=null;
	ScoreTimer timer = new ScoreTimer();
	final int REFRESH_RATE = 1000;
	
	public static Queue<PlayerDetails> lstPlayer = new LinkedList<PlayerDetails>();
	private long winTime = 0;

	private final String[] ARR_IN_GAME_MENU={"Main Menu","Exit"};
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		//requestWindowFeature(Window.FEATURE_NO_TITLE);
		int level=0;
		if(ShikakuGame.diff>=0 && ShikakuGame.diff<3)
			level=5;
		else if(ShikakuGame.diff>=3 && ShikakuGame.diff<6)
			level=7;
		else if(ShikakuGame.diff>=6 && ShikakuGame.diff<9)
			level=10;
		if(level>0)
			shikakuview=new Shikakuview(this, this, level);
		setContentView(shikakuview);
	}


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.activity_main, menu);
		View v = (View) menu.findItem(R.id.Timer).getActionView();
		txtTimer=(TextView) v.findViewById(R.id.txt_title);
		mHandler.sendEmptyMessage(BEGIN_TIMER);
		View spinnerLayout= menu.findItem(R.id.menu).getActionView();
		CustomSpinner spinner=(CustomSpinner) spinnerLayout.findViewById(R.id.menu_spinner);
		spinner.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, ARR_IN_GAME_MENU));
		spinner.setOnItemSelectedListener(this);
		//return super.onCreateOptionsMenu(menu);
		return true;
	}
	
	//StopWatch referenced from http://www.goldb.org/stopwatchjava.html
	
	Handler mHandler = new Handler()
	{
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case BEGIN_TIMER:
				timer.begintimer(); //start timer
				mHandler.sendEmptyMessage(REFRESH_TIMER);
				break;
			case REFRESH_TIMER:
				txtTimer.setText(""+ timer.retrieveExpiredTime()/1000);
				mHandler.sendEmptyMessageDelayed(REFRESH_TIMER,REFRESH_RATE); //text view is updated every second, 
				break;                                  
			case END_TIMER:
				mHandler.removeMessages(REFRESH_TIMER); // no more updates.
				timer.endtimer();//stop timer
				txtTimer.setText(""+ timer.retrieveExpiredTime()/1000);
				break;
			default:
				break;
			}
		}
	};

	public void finishGame() {
		{
			winTime = (timer.retrieveExpiredTime() / 1000);
			mHandler.sendEmptyMessage(END_TIMER);
			final AlertDialog alertDialog = new AlertDialog.Builder(this).create();
			alertDialog.setTitle("Shikaku Puzzle");
			alertDialog
					.setMessage("Congratulations! You have solved the puzzle in: "
							+ winTime + " Secs.");
			alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					alertDialog.dismiss();
					showPlayerNameDialog();
				}
			});
			alertDialog.setIcon(R.drawable.icon);
			alertDialog.show();
		}
	}

	private void showPlayerNameDialog() {
		final Dialog dialog = new Dialog(this);
		dialog.setTitle("Player Details Required");
		dialog.setContentView(R.layout.player_name_dialog);
		Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
		final EditText playerName = ((EditText) dialog.findViewById(R.id.playerName));
		dialogButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				String playerText = playerName.getText().toString();
				PlayerDetails player = new PlayerDetails(playerText, winTime);
				if(lstPlayer.size() < 10) {
					lstPlayer.add(player);
				}else {
					lstPlayer.remove();
					lstPlayer.add(player);
				}
				goToMainMenu();
				System.out.println("Size:::" + lstPlayer.size());
				dialog.dismiss();
			}
		});
		dialog.show();
	}
	
	public void onItemSelected(AdapterView<?> parent, View view, int pos,
			long id) {
		switch(pos){
		case 0:
			goToMainMenu();
			break;
		case 1:
			finish();
			break;
		}
	}
	
	private void goToMainMenu(){
		Intent intent = new Intent(this,ShikakuActivity.class);
		startActivity(intent);
	}

	public void onNothingSelected(AdapterView<?> arg0) {
		
	}

	public void onItemClick(AdapterView<?> parent, View view, int pos,
			long id) {
		switch(pos){
		case 0:
			Intent intent = new Intent(this,ShikakuActivity.class);
			startActivity(intent);
			break;
		case 1:
			finish();
			break;
		}
	}


	public void onClick(View v) {
		switch(v.getId()){
		case R.id.dialogButtonOK:
			break;
		}
		
	}
}
