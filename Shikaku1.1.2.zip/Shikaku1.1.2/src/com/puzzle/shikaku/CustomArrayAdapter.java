package com.puzzle.shikaku;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class CustomArrayAdapter extends ArrayAdapter<PlayerDetails> {

	private final Context context;
	private PlayerDetails[] values = null;
	
	public CustomArrayAdapter(ShikakuActivity context,PlayerDetails[] lstPlayer) {
		super(context, R.layout.scoreboard_row,lstPlayer);
		this.context = context;
		this.values = lstPlayer;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View rowView = convertView;
		LayoutInflater inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		if(convertView == null)
			rowView = inflater.inflate(R.layout.scoreboard_row, null);
		TextView playerName = (TextView) rowView.findViewById(R.id.playerName);
		TextView playerScore = (TextView) rowView.findViewById(R.id.playerScore);
		playerName.setText(values[position].getName());
		playerScore.setText(Long.toString(values[position].getScore()));
		return rowView;
	}
}
