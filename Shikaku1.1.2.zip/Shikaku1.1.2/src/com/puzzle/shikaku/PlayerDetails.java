package com.puzzle.shikaku;

public class PlayerDetails {

	private String playerName = null;
	private long score = 0;
	
	public PlayerDetails(String playerName,long score){
		this.playerName = playerName;
		this.score = score;
	}
	
	public String getName(){
		return playerName;
	}
	
	public long getScore(){
		return score;
	}
}
