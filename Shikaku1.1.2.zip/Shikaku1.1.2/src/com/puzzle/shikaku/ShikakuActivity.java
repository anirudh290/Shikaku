package com.puzzle.shikaku;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

// Referenced from Hello, Android, E. Burnette, The Pragmatic Programmers (2009).

public class ShikakuActivity extends Activity implements OnClickListener {
	Button New_Game,Scoreboard, About, Exit;
	String Difficulty[] = { "Novice", "Medium", "Expert" };
	
	// Referenced from Hello, Android, E. Burnette, The Pragmatic Programmers (2009).
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		New_Game = (Button) findViewById(R.id.New_Game_label);
		Scoreboard = (Button) findViewById(R.id.Scoreboard_label);
		About = (Button) findViewById(R.id.About_label);
		Exit = (Button) findViewById(R.id.Exit_label);
		New_Game.setOnClickListener(this);
		Scoreboard.setOnClickListener(this);
		About.setOnClickListener(this);
		Exit.setOnClickListener(this);
	}

	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.New_Game_label:
			NewGameDialog();
			break;
		case R.id.Scoreboard_label:
			if(MainPuzzleview.lstPlayer != null){
				showScoreboard();
			}else{
				Toast toast =  Toast.makeText(this, "No Previous records!!", Toast.LENGTH_SHORT);
			toast.show();
			}
			break;
		case R.id.About_label:
			Intent i = new Intent(this, About.class);
			startActivity(i);
			break;
		case R.id.Exit_label:
		    System.exit(0);
			break;
		}
	}

	private void showScoreboard() {
		final Dialog dialog = new Dialog(this);
		dialog.setTitle("Score Board");
		dialog.setContentView(R.layout.scoreboard_layout);
		Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
		ListView lstPlayerDetails = (ListView) dialog.findViewById(R.id.lstPlayerDetail);
		CustomArrayAdapter adapter = new CustomArrayAdapter(this,getPlayerDetails());
		lstPlayerDetails.setAdapter(adapter);
		dialogButton.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {
				dialog.dismiss();
			}
		});
		dialog.show();
	}

	private PlayerDetails[] getPlayerDetails() {
		PlayerDetails[] arrPlayerDetails = MainPuzzleview.lstPlayer.toArray(new PlayerDetails[MainPuzzleview.lstPlayer.size()]);
		return arrPlayerDetails;
	}

	private void NewGameDialog() {
		new AlertDialog.Builder(this).setTitle(R.string.New_Game_title)
				.setItems(Difficulty, new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialoginterface, int i) {
						startGame(i);
					}
				}).show();
	}

	private void startGame(int i) {
		Intent intent = new Intent(ShikakuActivity.this, ShikakuGame.class);
		intent.putExtra(ShikakuGame.KEY_DIFFICULTY, i);
		startActivity(intent);
	}
}